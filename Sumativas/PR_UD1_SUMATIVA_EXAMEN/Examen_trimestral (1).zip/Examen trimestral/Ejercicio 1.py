# -*- coding: utf-8 -*-
"""
Created on Fri Nov 29 09:56:39 2024

@author: RomeroRamosMiguel
"""

#realiza un programa donde un usuario escoja a partir del siguente menú, la opción que corresponda al combustible que desea


def menucombustible():
    print("¿Qué tipo de combustible deseas?")
    print("1. Sin plomo 95")
    print("2. Sin plomo 98")
    print("3. Gasóleo A")
    print("4. Gasóleo A+")

    try:
        opcion = int(input("Escribe el número de la opción que quieres (1-4): "))
        if opcion == 1:
            print("Elegiste Sin plomo 95. Ve al surtidor indicado.")
        elif opcion == 2:
            print("Elegiste Sin plomo 98. Ve al surtidor indicado.")
        elif opcion == 3:
            print("Elegiste Gasóleo A. Ve al surtidor indicado.")
        elif opcion == 4:
            
            print("Elegiste Gasóleo A+. Ve al surtidor indicado.")
        else:
            print("Opción no válida. Por favor, elige un número entre 1 y 4.")
    except ValueError:
        print("introduce numero del 1 al 4.")

# Llamar a la función principal
menucombustible()


  
  
    
    