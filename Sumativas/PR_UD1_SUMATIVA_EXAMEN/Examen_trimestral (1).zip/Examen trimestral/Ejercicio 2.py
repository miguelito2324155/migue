# -*- coding: utf-8 -*-
"""
Created on Fri Nov 29 10:15:00 2024

@author: RomeroRamosMiguel
"""

#utliza un bucle, realiza un pograma que permita introducir 6 números por teclado y presente por pantalla la suma total de valores positivos y la suma total de valores negativos

def sumar_numeros():
    suma_positivos = 0
    suma_negativos = 0

    print("Escribe 6 números (pueden ser positivos o negativos):")
    for i in range(6):
        try:
            numero = float(input(f"Número {i + 1}: "))
            if numero > 0:
                suma_positivos += numero
            elif numero < 0:
                suma_negativos += numero
        except ValueError:
            print("Eso no es un número válido. Intenta otra vez.")
            return

    print("\nResultados:")
    print(f"Suma de números positivos: {suma_positivos}")
    print(f"Suma de números negativos: {suma_negativos}")

sumar_numeros()


