#realiza un programa que permita visualizar por pantalla todos valores comprendidios entre dos numeros introduce por teclado y intervalo

def mostrar_valores():
    try:
   
        numero_inicial = int(input("Escribe el primer número: "))
        numero_final = int(input("Escribe el segundo número: "))
        intervalo = int(input("Escribe el intervalo: "))

        if intervalo <= 0:
            print("El intervalo debe ser mayor que 0.")
            return


        print(f"\Valores desde {numero_inicial} hasta {numero_final} con intervalo de {intervalo}:")
        for i in range(numero_inicial, numero_final + 1, intervalo):
            print(i, end=" ")

        print()  
    except ValueError:
        print("introduce numeros validos.")


mostrar_valores()
