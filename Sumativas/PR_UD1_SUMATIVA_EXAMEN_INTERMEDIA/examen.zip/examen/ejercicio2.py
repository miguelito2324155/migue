



var1=float(input("introduce el primer numero: "))

var2=float(input("introduce el segundo numero: "))

print (var1 + var2)

print (var1 / var2)
