
#puse el float y parentesis

var1=float(input("introduce el primer numero: "))

#puse el float y parentesis y agregue las comillas

var2=float(input("introduce el segundo numero: "))


#cambie y lo hice mas sencillo con esto se sumahn y te printea el resultado


print(var1 + var2) 
