#Ejercicio 1
entrada = input("Introduce 6 números separados por guion: ")
numeros = list(map(int, entrada.split('-')))
maximo = max(numeros)
minimo = min(numeros)
promedio = sum(numeros) / len(numeros)
nueva_lista = [num for num in numeros if num > promedio]
print(f"Máximo: {maximo}")
print(f"Mínimo: {minimo}")
print(f"Promedio: {promedio:.4f}")
print(f"Nueva lista: {nueva_lista}")
